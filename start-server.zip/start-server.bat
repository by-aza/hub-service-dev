@echo off
title HUB Local Server
setlocal enabledelayedexpansion

:: ================================
:: CONFIG
:: ================================
set ROOT=D:\GitHub\hub-service-dev\hub-service
set PORT=8000
set START_PAGE=http://localhost:%PORT%/modules/formulare/telefoane-clienti.html

:: ================================
:: COLOR CODES
:: ================================
for /f "tokens=1,2 delims==" %%a in ('"prompt $H & for %%b in (1) do rem"') do set "BS=%%a"
echo.

:: ================================
:: CHECK IF PORT IS FREE
:: ================================
echo Verific portul %PORT%...
netstat -ano | findstr :%PORT% >nul
if %errorlevel%==0 (
    echo %BS%[31mEroare:%BS%[0m Portul %PORT% este deja folosit.
    echo Inchide aplicatia care foloseste portul si incearca din nou.
    pause
    exit /b
)

:: ================================
:: STARTING SERVER
:: ================================
echo.
echo ================================
echo Pornesc serverul local pentru HUB
echo Director: %ROOT%
echo Port: %PORT%
echo ================================
echo.

cd /d "%ROOT%"

:: Try python
python --version >nul 2>&1
if %errorlevel%==0 (
    echo %BS%[32mPython detectat. Pornesc serverul...%BS%[0m
    start "" python -m http.server %PORT%
    goto OPEN_BROWSER
)

:: Try py
py --version >nul 2>&1
if %errorlevel%==0 (
    echo %BS%[32mPython (py) detectat. Pornesc serverul...%BS%[0m
    start "" py -m http.server %PORT%
    goto OPEN_BROWSER
)

:: No python found
echo %BS%[31mEroare:%BS%[0m Python nu este instalat sau nu este in PATH.
echo Instaleaza Python de pe python.org.
pause
exit /b

:OPEN_BROWSER
echo.
echo %BS%[32mServer pornit cu succes!%BS%[0m
echo Deschid pagina:
echo %START_PAGE%
start "" "%START_PAGE%"
echo.
pause